"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { FLOW, FLOW_ORDER } from "@/lib/flow";

export default function Navbar() {
  const pathname = usePathname();

  const activeIndex = Math.max(
    FLOW_ORDER.findIndex((key) => pathname.startsWith(FLOW[key].href)),
    0
  );

  return (
    // h-16 includes the border (box-border), so pages can rely on --nav-h.
    <header className="relative z-50 h-16 border-b border-slate-200/70 bg-white/95 shadow-[0_1px_6px_rgba(15,23,42,0.04)] backdrop-blur-xl">
      <div className="flex h-full items-center justify-between px-6">
        <Link href="/" className="group flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-600 text-xs font-bold text-white shadow-[0_3px_10px_rgba(37,99,235,0.24)] transition-transform duration-200 group-hover:scale-[1.03]">
            S
          </div>

          <div className="leading-none">
            <p className="text-sm font-semibold tracking-tight text-slate-950">
              SIVORA
            </p>
            <p className="mt-1 text-[10px] font-medium text-slate-500">
              Spatial intelligence platform
            </p>
          </div>
        </Link>

        <nav
          aria-label="Workflow"
          className="relative rounded-xl bg-slate-100/90 p-1"
        >
          {/* Sliding active background */}
          <div
            aria-hidden
            className="absolute bottom-1 top-1 rounded-lg border border-slate-200/70 bg-white shadow-[0_1px_5px_rgba(15,23,42,0.08)] transition-all duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]"
            style={{
              width: "calc((100% - 8px) / 3)",
              left: `calc(4px + ${activeIndex} * ((100% - 8px) / 3))`,
            }}
          />

          <ol className="relative z-10 grid grid-cols-3">
            {FLOW_ORDER.map((key, index) => {
              const step = FLOW[key];
              const active = index === activeIndex;
              const done = index < activeIndex;

              return (
                <li key={key}>
                  <Link
                    href={step.href}
                    aria-current={active ? "step" : undefined}
                    className="flex min-w-[112px] items-center justify-center gap-2 rounded-lg px-3 py-1.5 transition-colors"
                  >
                    <span
                      className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10px] font-semibold transition-colors ${
                        active
                          ? step.badge
                          : done
                            ? "bg-slate-200 text-slate-700"
                            : "bg-slate-200/70 text-slate-500"
                      }`}
                    >
                      {done ? "✓" : step.index}
                    </span>

                    <span className="text-left leading-none">
                      <span
                        className={`block text-xs font-semibold transition-colors ${
                          active
                            ? "text-slate-950"
                            : "text-slate-600 hover:text-slate-900"
                        }`}
                      >
                        {step.label}
                      </span>
                      <span
                        className={`mt-1 block text-[10px] font-medium transition-colors ${
                          active ? step.text : "text-slate-500"
                        }`}
                      >
                        {step.verb}
                      </span>
                    </span>
                  </Link>
                </li>
              );
            })}
          </ol>
        </nav>
      </div>
    </header>
  );
}
